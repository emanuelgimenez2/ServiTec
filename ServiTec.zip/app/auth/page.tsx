"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { User, Mail, Lock, Phone, MapPin, Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  })

  const [registerData, setRegisterData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    address: "",
  })

  useEffect(() => {
    // Check if user is already logged in
    const user = localStorage.getItem("servitec_user")
    if (user) {
      router.push("/")
    }
  }, [router])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      // Get users from "usuario" collection
      const usuarioCollection = JSON.parse(localStorage.getItem("usuario") || "[]")

      // Check for admin credentials first
      if (loginData.email === "admin@servitec.com" && loginData.password === "admin123") {
        // Check if admin already exists in collection
        let adminUser = usuarioCollection.find((u) => u.email === "admin@servitec.com")

        if (!adminUser) {
          // Create admin user in collection
          adminUser = {
            id: "admin_" + Date.now(),
            name: "Administrador",
            email: "admin@servitec.com",
            password: "admin123",
            role: "administrador",
            phone: "+54 9 3442 646670",
            address: "Concepción del Uruguay, Entre Ríos",
            createdAt: new Date().toISOString(),
          }
          usuarioCollection.push(adminUser)
          localStorage.setItem("usuario", JSON.stringify(usuarioCollection))
        }

        localStorage.setItem("servitec_user", JSON.stringify(adminUser))
        toast({
          title: "¡Bienvenido Administrador!",
          description: "Has iniciado sesión correctamente.",
        })

        // Trigger custom event for navbar update
        window.dispatchEvent(new CustomEvent("userUpdated"))
        router.push("/admin")
      } else {
        // Check for regular user
        const user = usuarioCollection.find((u) => u.email === loginData.email && u.password === loginData.password)

        if (user) {
          localStorage.setItem("servitec_user", JSON.stringify(user))
          toast({
            title: "¡Bienvenido!",
            description: "Has iniciado sesión correctamente.",
          })

          // Trigger custom event for navbar update
          window.dispatchEvent(new CustomEvent("userUpdated"))
          router.push("/")
        } else {
          toast({
            title: "Error de autenticación",
            description: "Email o contraseña incorrectos.",
            variant: "destructive",
          })
        }
      }
      setLoading(false)
    }, 1000)
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    if (registerData.password !== registerData.confirmPassword) {
      toast({
        title: "Error",
        description: "Las contraseñas no coinciden.",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    // Simulate API call
    setTimeout(() => {
      const usuarioCollection = JSON.parse(localStorage.getItem("usuario") || "[]")

      // Check if user already exists
      if (usuarioCollection.find((u) => u.email === registerData.email)) {
        toast({
          title: "Error",
          description: "Ya existe una cuenta con este email.",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      const newUser = {
        id: "user_" + Date.now(),
        name: registerData.name,
        email: registerData.email,
        password: registerData.password,
        phone: registerData.phone,
        address: registerData.address,
        role: "usuario", // Por defecto todos son "usuario"
        createdAt: new Date().toISOString(),
      }

      usuarioCollection.push(newUser)
      localStorage.setItem("usuario", JSON.stringify(usuarioCollection))
      localStorage.setItem("servitec_user", JSON.stringify(newUser))

      // Initialize empty cart and wishlist for new user
      const carritoCollection = JSON.parse(localStorage.getItem("carrito") || "[]")
      carritoCollection.push({
        userId: newUser.id,
        items: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      })
      localStorage.setItem("carrito", JSON.stringify(carritoCollection))

      const wishlistCollection = JSON.parse(localStorage.getItem("lista_de_deseos") || "[]")
      wishlistCollection.push({
        userId: newUser.id,
        items: [],
        categories: [{ id: "general", name: "General", color: "bg-gray-500" }],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      })
      localStorage.setItem("lista_de_deseos", JSON.stringify(wishlistCollection))

      toast({
        title: "¡Cuenta creada!",
        description: "Tu cuenta ha sido creada exitosamente.",
      })

      // Trigger custom event for navbar update
      window.dispatchEvent(new CustomEvent("userUpdated"))
      router.push("/")
      setLoading(false)
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 flex items-center justify-center p-4 pt-20">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">ServiTec</CardTitle>
          <p className="text-gray-600">Accede a tu cuenta o regístrate</p>
        </CardHeader>
        <CardContent>
          <Tabs value={isLogin ? "login" : "register"} onValueChange={(value) => setIsLogin(value === "login")}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Iniciar Sesión</TabsTrigger>
              <TabsTrigger value="register">Registrarse</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="tu@email.com"
                      value={loginData.email}
                      onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="password">Contraseña</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Tu contraseña"
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      className="pl-10 pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Iniciando sesión..." : "Iniciar Sesión"}
                </Button>
                <div className="text-center text-sm text-gray-600">
                  <p>Cuenta de prueba admin:</p>
                  <p>Email: admin@servitec.com</p>
                  <p>Contraseña: admin123</p>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-4">
                <div>
                  <Label htmlFor="name">Nombre completo</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="name"
                      type="text"
                      placeholder="Tu nombre completo"
                      value={registerData.name}
                      onChange={(e) => setRegisterData({ ...registerData, name: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="register-email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="register-email"
                      type="email"
                      placeholder="tu@email.com"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="phone">Teléfono</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+54 9 3442 646670"
                      value={registerData.phone}
                      onChange={(e) => setRegisterData({ ...registerData, phone: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="address">Dirección</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="address"
                      type="text"
                      placeholder="Tu dirección"
                      value={registerData.address}
                      onChange={(e) => setRegisterData({ ...registerData, address: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="register-password">Contraseña</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="register-password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Tu contraseña"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                      className="pl-10 pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <Label htmlFor="confirm-password">Confirmar contraseña</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="confirm-password"
                      type="password"
                      placeholder="Confirma tu contraseña"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({ ...registerData, confirmPassword: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Creando cuenta..." : "Crear Cuenta"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
