"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Monitor, CheckCircle, Clock, Shield, Star, Phone, Mail, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

const services = [
  {
    title: "Limpieza Completa",
    description: "Limpieza interna y externa, cambio de pasta térmica",
    price: "Desde $15.000",
    duration: "2-3 horas",
  },
  {
    title: "Cambio de Componentes",
    description: "RAM, disco duro, teclado, pantalla, batería",
    price: "Desde $25.000",
    duration: "1-2 días",
  },
  {
    title: "Reparación de Software",
    description: "Eliminación de virus, optimización del sistema",
    price: "Desde $12.000",
    duration: "2-4 horas",
  },
  {
    title: "Formateo e Instalación",
    description: "Windows 11, drivers, programas básicos",
    price: "Desde $18.000",
    duration: "4-6 horas",
  },
  {
    title: "Recuperación de Datos",
    description: "Recuperación de archivos perdidos o dañados",
    price: "Desde $30.000",
    duration: "1-3 días",
  },
  {
    title: "Instalación de Programas",
    description: "Office, antivirus, programas específicos con licencia",
    price: "Desde $8.000",
    duration: "1-2 horas",
  },
]

const portfolio = [
  {
    id: 1,
    title: "Notebook HP Pavilion - Limpieza Completa",
    description: "Limpieza interna, cambio de pasta térmica, optimización",
    image: "/placeholder.svg?height=300&width=400",
    before: "Sobrecalentamiento constante",
    after: "Temperatura normal, rendimiento óptimo",
  },
  {
    id: 2,
    title: "PC Gamer - Upgrade Completo",
    description: "Cambio de RAM, SSD, tarjeta gráfica",
    image: "/placeholder.svg?height=300&width=400",
    before: "Lentitud en juegos",
    after: "Rendimiento gaming excelente",
  },
  {
    id: 3,
    title: "Notebook Dell - Recuperación de Datos",
    description: "Recuperación de 500GB de archivos importantes",
    image: "/placeholder.svg?height=300&width=400",
    before: "Disco duro dañado",
    after: "100% de datos recuperados",
  },
]

const process = [
  {
    step: 1,
    title: "Diagnóstico Gratuito",
    description: "Evaluamos el problema y te damos un presupuesto sin costo",
  },
  {
    step: 2,
    title: "Presupuesto Detallado",
    description: "Te explicamos qué necesita tu equipo y los costos involucrados",
  },
  {
    step: 3,
    title: "Reparación",
    description: "Realizamos el trabajo con repuestos originales y garantía",
  },
  {
    step: 4,
    title: "Pruebas y Entrega",
    description: "Probamos todo funcione correctamente antes de entregarte tu equipo",
  },
]

const testimonials = [
  {
    name: "Carlos Rodríguez",
    comment:
      "Mi notebook tenía problemas graves y pensé que no tenía arreglo. Los chicos de ServiTec la dejaron como nueva.",
    rating: 5,
    service: "Reparación completa",
  },
  {
    name: "María González",
    comment: "Excelente servicio, muy profesionales. Recuperaron todos mis archivos importantes.",
    rating: 5,
    service: "Recuperación de datos",
  },
  {
    name: "Roberto Silva",
    comment: "Rápido y eficiente. El precio fue muy justo y la garantía me dio mucha tranquilidad.",
    rating: 5,
    service: "Cambio de componentes",
  },
]

export default function ReparacionPage() {
  const [formData, setFormData] = useState({
    nombre: "",
    telefono: "",
    email: "",
    tipoEquipo: "",
    problema: "",
    urgencia: "",
  })
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    toast({
      title: "Solicitud enviada",
      description: "Te contactaremos pronto para coordinar el diagnóstico gratuito.",
    })

    // Guardar mensaje en admin
    const message = {
      id: Date.now().toString(),
      nombre: formData.nombre,
      telefono: formData.telefono,
      email: formData.email,
      serviceType: "reparacion",
      mensaje: `Tipo de equipo: ${formData.tipoEquipo}\nProblema: ${formData.problema}\nUrgencia: ${formData.urgencia}`,
      status: "unread",
      createdAt: new Date().toISOString(),
    }

    const existingMessages = JSON.parse(localStorage.getItem("admin_messages") || "[]")
    localStorage.setItem("admin_messages", JSON.stringify([...existingMessages, message]))

    setFormData({
      nombre: "",
      telefono: "",
      email: "",
      tipoEquipo: "",
      problema: "",
      urgencia: "",
    })
  }

  return (
    <div className="min-h-screen bg-white pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 via-purple-600 to-orange-500 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <Monitor className="w-12 h-12 mr-4" />
                <Badge className="bg-white/20 text-white">Servicio Técnico</Badge>
              </div>
              <h1 className="text-5xl font-bold mb-6">Reparación de Computadoras</h1>
              <p className="text-xl mb-8 text-white/90">
                Servicio técnico especializado en notebooks y PCs de escritorio. Diagnóstico gratuito y garantía en
                todos nuestros trabajos.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-white text-purple-600 hover:bg-gray-100 font-semibold"
                  onClick={() => document.getElementById("contacto")?.scrollIntoView({ behavior: "smooth" })}
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Solicitar Diagnóstico Gratuito
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-purple-600"
                >
                  <Mail className="w-5 h-5 mr-2" />
                  +54 9 3442 646670
                </Button>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Reparación de computadoras"
                width={600}
                height={400}
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Nuestros Servicios</h2>
            <p className="text-xl text-gray-600">Soluciones completas para todos los problemas de tu equipo</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300 border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <CheckCircle className="w-6 h-6 text-green-500 mr-3" />
                    <h3 className="text-lg font-semibold text-gray-900">{service.title}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-lg font-bold text-purple-600">{service.price}</p>
                      <p className="text-sm text-gray-500 flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {service.duration}
                      </p>
                    </div>
                    <Shield className="w-8 h-8 text-orange-500" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Nuestro Proceso</h2>
            <p className="text-xl text-gray-600">Así trabajamos para garantizar la mejor experiencia</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-orange-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                  {item.step}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Trabajos Realizados</h2>
            <p className="text-xl text-gray-600">Algunos de nuestros casos de éxito</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {portfolio.map((work) => (
              <Card key={work.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="relative h-48">
                  <Image src={work.image || "/placeholder.svg"} alt={work.title} fill className="object-cover" />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{work.title}</h3>
                  <p className="text-gray-600 mb-4">{work.description}</p>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <span className="text-sm font-medium text-red-600 mr-2">Antes:</span>
                      <span className="text-sm text-gray-600">{work.before}</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-sm font-medium text-green-600 mr-2">Después:</span>
                      <span className="text-sm text-gray-600">{work.after}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Lo que dicen nuestros clientes</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4">"{testimonial.comment}"</p>
                  <div>
                    <p className="font-semibold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-500">{testimonial.service}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section id="contacto" className="py-20 bg-gradient-to-br from-purple-600 to-orange-500 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Solicita tu Diagnóstico Gratuito</h2>
            <p className="text-xl text-white/90">
              Contanos qué problema tiene tu equipo y te daremos un presupuesto sin costo
            </p>
          </div>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Nombre completo</label>
                    <Input
                      value={formData.nombre}
                      onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                      className="bg-white/10 border-white/20 text-white placeholder:text-white/70"
                      placeholder="Tu nombre"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Teléfono</label>
                    <Input
                      value={formData.telefono}
                      onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                      className="bg-white/10 border-white/20 text-white placeholder:text-white/70"
                      placeholder="+54 9 3442 646670"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/70"
                    placeholder="tu@email.com"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Tipo de equipo</label>
                    <Select
                      value={formData.tipoEquipo}
                      onValueChange={(value) => setFormData({ ...formData, tipoEquipo: value })}
                    >
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue placeholder="Selecciona el tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="notebook">Notebook</SelectItem>
                        <SelectItem value="pc-escritorio">PC de Escritorio</SelectItem>
                        <SelectItem value="all-in-one">All-in-One</SelectItem>
                        <SelectItem value="otro">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Urgencia</label>
                    <Select
                      value={formData.urgencia}
                      onValueChange={(value) => setFormData({ ...formData, urgencia: value })}
                    >
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue placeholder="Nivel de urgencia" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="baja">No es urgente</SelectItem>
                        <SelectItem value="media">Moderada</SelectItem>
                        <SelectItem value="alta">Urgente</SelectItem>
                        <SelectItem value="critica">Muy urgente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Describe el problema</label>
                  <Textarea
                    value={formData.problema}
                    onChange={(e) => setFormData({ ...formData, problema: e.target.value })}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/70"
                    placeholder="Contanos qué problema tiene tu equipo..."
                    rows={4}
                    required
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-white text-purple-600 hover:bg-gray-100 font-semibold"
                >
                  Enviar Solicitud
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
