"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"
import {
  Camera,
  Shield,
  Eye,
  Smartphone,
  Cloud,
  Clock,
  MapPin,
  Phone,
  Mail,
  Star,
  Home,
  Building,
  Store,
  Factory,
  AlertTriangle,
  Wifi,
  HardDrive,
  Monitor,
} from "lucide-react"

export default function CamarasPage() {
  const [formData, setFormData] = useState({
    nombre: "",
    telefono: "",
    email: "",
    direccion: "",
    tipoPropiedad: "",
    areaCubrir: "",
    numeroCamaras: "",
    tiposCamara: [] as string[],
    presupuesto: "",
    comentarios: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (tipo: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      tiposCamara: checked ? [...prev.tiposCamara, tipo] : prev.tiposCamara.filter((t) => t !== tipo),
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Simular envío
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Guardar mensaje en el sistema de administración
      const message = {
        id: Date.now().toString(),
        serviceType: "camaras",
        nombre: formData.nombre,
        telefono: formData.telefono,
        email: formData.email,
        mensaje: `Dirección: ${formData.direccion}\nTipo de propiedad: ${formData.tipoPropiedad}\nÁrea a cubrir: ${formData.areaCubrir}\nNúmero de cámaras: ${formData.numeroCamaras}\nTipos de cámaras: ${formData.tiposCamara.join(", ")}\nPresupuesto: ${formData.presupuesto}\nComentarios: ${formData.comentarios}`,
        status: "unread",
        createdAt: new Date().toISOString(),
      }

      const existingMessages = JSON.parse(localStorage.getItem("admin_messages") || "[]")
      localStorage.setItem("admin_messages", JSON.stringify([...existingMessages, message]))

      toast({
        title: "¡Solicitud enviada!",
        description: "Nos pondremos en contacto contigo pronto para coordinar la evaluación gratuita.",
      })

      setFormData({
        nombre: "",
        telefono: "",
        email: "",
        direccion: "",
        tipoPropiedad: "",
        areaCubrir: "",
        numeroCamaras: "",
        tiposCamara: [],
        presupuesto: "",
        comentarios: "",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Hubo un problema al enviar tu solicitud. Por favor, intenta nuevamente.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-50">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=600&width=1200')] opacity-10" />
        <div className="relative container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-white/10 backdrop-blur-sm rounded-full p-4">
                <Camera className="w-12 h-12 text-purple-300" />
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
              Cámaras de Seguridad
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-purple-100 leading-relaxed">
              Protege lo que más importa con sistemas de videovigilancia de última generación
            </p>
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <Badge className="bg-green-500/20 text-green-300 border-green-500/30 px-4 py-2 text-sm">
                <Eye className="w-4 h-4 mr-2" />
                Visión Nocturna
              </Badge>
              <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 px-4 py-2 text-sm">
                <Smartphone className="w-4 h-4 mr-2" />
                App Móvil
              </Badge>
              <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30 px-4 py-2 text-sm">
                <Cloud className="w-4 h-4 mr-2" />
                Almacenamiento Cloud
              </Badge>
            </div>
            <Button
              size="lg"
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-4 text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
              onClick={() => document.getElementById("contact-form")?.scrollIntoView({ behavior: "smooth" })}
            >
              Evaluación Gratuita
              <Camera className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Sistemas de Seguridad Integrales</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Tecnología avanzada para proteger tu hogar, negocio o empresa con monitoreo 24/7 y alertas en tiempo real
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Camera className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">Cámaras 4K Ultra HD</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-4">
                  Resolución 4K para capturar cada detalle con claridad excepcional, tanto de día como de noche.
                </p>
                <div className="bg-purple-50 rounded-lg p-3">
                  <p className="text-sm font-semibold text-purple-700">Calidad profesional garantizada</p>
                </div>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Smartphone className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">Monitoreo Remoto</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-4">
                  Accede a tus cámaras desde cualquier lugar del mundo a través de nuestra app móvil intuitiva.
                </p>
                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-sm font-semibold text-blue-700">Control total desde tu celular</p>
                </div>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Eye className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">Visión Nocturna</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-4">
                  Tecnología infrarroja avanzada para vigilancia clara y nítida incluso en completa oscuridad.
                </p>
                <div className="bg-green-50 rounded-lg p-3">
                  <p className="text-sm font-semibold text-green-700">Protección las 24 horas</p>
                </div>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <AlertTriangle className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">Detección Inteligente</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-4">
                  IA avanzada para detectar personas, vehículos y movimientos sospechosos con alertas instantáneas.
                </p>
                <div className="bg-orange-50 rounded-lg p-3">
                  <p className="text-sm font-semibold text-orange-700">Alertas inteligentes en tiempo real</p>
                </div>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="bg-gradient-to-br from-teal-500 to-teal-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Cloud className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">Almacenamiento Cloud</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-4">
                  Respaldo automático en la nube con acceso seguro a grabaciones desde cualquier dispositivo.
                </p>
                <div className="bg-teal-50 rounded-lg p-3">
                  <p className="text-sm font-semibold text-teal-700">Tus grabaciones siempre seguras</p>
                </div>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">Instalación Profesional</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-4">
                  Técnicos certificados realizan la instalación completa con garantía extendida y soporte técnico.
                </p>
                <div className="bg-indigo-50 rounded-lg p-3">
                  <p className="text-sm font-semibold text-indigo-700">Instalación garantizada</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Types Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Soluciones para Cada Necesidad</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Sistemas personalizados según el tipo de propiedad y nivel de seguridad requerido
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Home className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-lg font-bold">Residencial</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• 2-8 cámaras</li>
                  <li>• Visión nocturna</li>
                  <li>• App móvil</li>
                  <li>• Grabación local</li>
                  <li>• Desde $299</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Store className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-lg font-bold">Comercial</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• 4-16 cámaras</li>
                  <li>• Detección IA</li>
                  <li>• Almacenamiento cloud</li>
                  <li>• Monitoreo 24/7</li>
                  <li>• Desde $599</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Building className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-lg font-bold">Empresarial</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• 8-32 cámaras</li>
                  <li>• Sistema integrado</li>
                  <li>• Control de acceso</li>
                  <li>• Redundancia</li>
                  <li>• Desde $1,299</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Factory className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-lg font-bold">Industrial</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• 16+ cámaras</li>
                  <li>• Resistente clima</li>
                  <li>• Análisis avanzado</li>
                  <li>• Integración sistemas</li>
                  <li>• Cotización personalizada</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Tecnología de Vanguardia</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Equipos de las mejores marcas mundiales con la última tecnología en videovigilancia
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-4">
                <Monitor className="w-8 h-8 text-purple-600 mr-3" />
                <h3 className="font-bold text-lg">Resolución 4K</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Cámaras con resolución Ultra HD 4K (3840x2160) para capturar cada detalle con claridad excepcional.
              </p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• 8 megapíxeles de resolución</li>
                <li>• Zoom digital sin pérdida</li>
                <li>• Reconocimiento facial</li>
              </ul>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-4">
                <Wifi className="w-8 h-8 text-blue-600 mr-3" />
                <h3 className="font-bold text-lg">Conectividad IP</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Cámaras IP con conectividad WiFi y Ethernet para instalación flexible y acceso remoto.
              </p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• WiFi 6 de alta velocidad</li>
                <li>• PoE (Power over Ethernet)</li>
                <li>• Configuración plug & play</li>
              </ul>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-4">
                <HardDrive className="w-8 h-8 text-green-600 mr-3" />
                <h3 className="font-bold text-lg">Almacenamiento</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Múltiples opciones de almacenamiento: local, cloud y híbrido para máxima seguridad de datos.
              </p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• NVR con hasta 8TB</li>
                <li>• Backup automático en cloud</li>
                <li>• Retención configurable</li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section id="contact-form" className="py-20 bg-gradient-to-br from-purple-50 to-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Solicita tu Evaluación Gratuita</h2>
              <p className="text-xl text-gray-600">
                Nuestros expertos evaluarán tu propiedad y diseñarán el sistema de seguridad perfecto para tus
                necesidades
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              {/* Contact Info */}
              <div className="space-y-8">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">¿Por qué elegir ServiTec?</h3>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="bg-purple-100 rounded-full p-2 mr-4">
                        <Star className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Instaladores Certificados</h4>
                        <p className="text-gray-600">Técnicos especializados con años de experiencia</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-green-100 rounded-full p-2 mr-4">
                        <Shield className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Garantía Extendida</h4>
                        <p className="text-gray-600">3 años de garantía en equipos y instalación</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-orange-100 rounded-full p-2 mr-4">
                        <Clock className="w-5 h-5 text-orange-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Soporte 24/7</h4>
                        <p className="text-gray-600">Atención técnica las 24 horas del día</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6">
                  <h4 className="font-bold text-purple-900 mb-4">Contacto Directo</h4>
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <Phone className="w-5 h-5 text-purple-600 mr-3" />
                      <span className="text-purple-800">+54 11 1234-5678</span>
                    </div>
                    <div className="flex items-center">
                      <Mail className="w-5 h-5 text-purple-600 mr-3" />
                      <span className="text-purple-800">camaras@servitec.com</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="w-5 h-5 text-purple-600 mr-3" />
                      <span className="text-purple-800">Servicio en CABA y GBA</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Form */}
              <Card className="shadow-xl border-0">
                <CardHeader>
                  <CardTitle className="text-2xl text-center">Evaluación Gratuita</CardTitle>
                  <CardDescription className="text-center">
                    Completa el formulario para recibir una cotización personalizada
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="nombre" className="block text-sm font-medium text-gray-700 mb-2">
                          Nombre Completo *
                        </label>
                        <Input
                          id="nombre"
                          name="nombre"
                          type="text"
                          required
                          value={formData.nombre}
                          onChange={handleInputChange}
                          className="w-full"
                          placeholder="Tu nombre completo"
                        />
                      </div>
                      <div>
                        <label htmlFor="telefono" className="block text-sm font-medium text-gray-700 mb-2">
                          Teléfono *
                        </label>
                        <Input
                          id="telefono"
                          name="telefono"
                          type="tel"
                          required
                          value={formData.telefono}
                          onChange={handleInputChange}
                          className="w-full"
                          placeholder="+54 11 1234-5678"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                        Email *
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full"
                        placeholder="tu@email.com"
                      />
                    </div>

                    <div>
                      <label htmlFor="direccion" className="block text-sm font-medium text-gray-700 mb-2">
                        Dirección de Instalación *
                      </label>
                      <Input
                        id="direccion"
                        name="direccion"
                        type="text"
                        required
                        value={formData.direccion}
                        onChange={handleInputChange}
                        className="w-full"
                        placeholder="Calle, número, ciudad"
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="tipoPropiedad" className="block text-sm font-medium text-gray-700 mb-2">
                          Tipo de Propiedad *
                        </label>
                        <Select
                          value={formData.tipoPropiedad}
                          onValueChange={(value) => handleSelectChange("tipoPropiedad", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecciona el tipo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="casa">Casa</SelectItem>
                            <SelectItem value="departamento">Departamento</SelectItem>
                            <SelectItem value="oficina">Oficina</SelectItem>
                            <SelectItem value="comercio">Comercio</SelectItem>
                            <SelectItem value="empresa">Empresa</SelectItem>
                            <SelectItem value="industria">Industria</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label htmlFor="areaCubrir" className="block text-sm font-medium text-gray-700 mb-2">
                          Área a Cubrir (m²) *
                        </label>
                        <Input
                          id="areaCubrir"
                          name="areaCubrir"
                          type="text"
                          required
                          value={formData.areaCubrir}
                          onChange={handleInputChange}
                          className="w-full"
                          placeholder="Ej: 200 m²"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="numeroCamaras" className="block text-sm font-medium text-gray-700 mb-2">
                          Número de Cámaras Estimado
                        </label>
                        <Select
                          value={formData.numeroCamaras}
                          onValueChange={(value) => handleSelectChange("numeroCamaras", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Cantidad estimada" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="2-4">2-4 cámaras</SelectItem>
                            <SelectItem value="4-8">4-8 cámaras</SelectItem>
                            <SelectItem value="8-16">8-16 cámaras</SelectItem>
                            <SelectItem value="16+">Más de 16 cámaras</SelectItem>
                            <SelectItem value="no-se">No estoy seguro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label htmlFor="presupuesto" className="block text-sm font-medium text-gray-700 mb-2">
                          Presupuesto Aproximado
                        </label>
                        <Select
                          value={formData.presupuesto}
                          onValueChange={(value) => handleSelectChange("presupuesto", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Rango de presupuesto" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="300-500">$300 - $500</SelectItem>
                            <SelectItem value="500-1000">$500 - $1,000</SelectItem>
                            <SelectItem value="1000-2000">$1,000 - $2,000</SelectItem>
                            <SelectItem value="2000+">Más de $2,000</SelectItem>
                            <SelectItem value="flexible">Flexible</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-3">
                        Tipos de Cámaras de Interés (selecciona todas las que apliquen)
                      </label>
                      <div className="grid md:grid-cols-2 gap-3">
                        {[
                          "Cámaras IP 4K",
                          "Cámaras con visión nocturna",
                          "Cámaras PTZ (movimiento)",
                          "Cámaras ocultas/discretas",
                          "Cámaras resistentes al clima",
                          "Cámaras con audio",
                        ].map((tipo) => (
                          <div key={tipo} className="flex items-center space-x-2">
                            <Checkbox
                              id={tipo}
                              checked={formData.tiposCamara.includes(tipo)}
                              onCheckedChange={(checked) => handleCheckboxChange(tipo, checked as boolean)}
                            />
                            <label htmlFor={tipo} className="text-sm text-gray-700">
                              {tipo}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label htmlFor="comentarios" className="block text-sm font-medium text-gray-700 mb-2">
                        Comentarios Adicionales
                      </label>
                      <Textarea
                        id="comentarios"
                        name="comentarios"
                        value={formData.comentarios}
                        onChange={handleInputChange}
                        className="w-full"
                        rows={4}
                        placeholder="Describe tus necesidades específicas, áreas críticas a cubrir, horarios de mayor actividad, etc."
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-3 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
                          Enviando...
                        </>
                      ) : (
                        <>
                          Solicitar Evaluación Gratuita
                          <Camera className="ml-2 w-5 h-5" />
                        </>
                      )}
                    </Button>

                    <p className="text-sm text-gray-500 text-center">
                      * Campos obligatorios. La evaluación es completamente gratuita y sin compromiso.
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Preguntas Frecuentes</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Resolvemos las dudas más comunes sobre sistemas de videovigilancia
            </p>
          </div>

          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-lg mb-3 text-gray-900">¿Qué incluye la instalación?</h3>
              <p className="text-gray-600">
                Incluye: cámaras, NVR/DVR, cables, soportes, configuración completa, app móvil, pruebas de
                funcionamiento y capacitación básica.
              </p>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-lg mb-3 text-gray-900">¿Cuánto tiempo toma la instalación?</h3>
              <p className="text-gray-600">
                Depende del número de cámaras: 2-4 cámaras (4-6 horas), 4-8 cámaras (6-8 horas), sistemas más grandes
                pueden requerir 1-2 días.
              </p>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-lg mb-3 text-gray-900">¿Puedo ver las cámaras desde mi celular?</h3>
              <p className="text-gray-600">
                Sí, incluimos app móvil gratuita para iOS y Android. Podrás ver en vivo, recibir alertas y revisar
                grabaciones desde cualquier lugar.
              </p>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-lg mb-3 text-gray-900">¿Qué pasa si se corta la luz?</h3>
              <p className="text-gray-600">
                Ofrecemos UPS (sistema de respaldo) opcional que mantiene el sistema funcionando por 2-4 horas durante
                cortes de energía.
              </p>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-lg mb-3 text-gray-900">¿Las cámaras funcionan de noche?</h3>
              <p className="text-gray-600">
                Sí, todas nuestras cámaras incluyen visión nocturna infrarroja con alcance de 20-30 metros en completa
                oscuridad.
              </p>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-lg mb-3 text-gray-900">¿Qué garantía ofrecen?</h3>
              <p className="text-gray-600">
                3 años de garantía en equipos, 2 años en instalación y soporte técnico gratuito durante toda la vida
                útil del sistema.
              </p>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
