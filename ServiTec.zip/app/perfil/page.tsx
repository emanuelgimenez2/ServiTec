"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { User, Mail, Phone, MapPin, Lock, Save, ArrowLeft, Calendar, ShoppingCart, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

export default function PerfilPage() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(false)
  const [stats, setStats] = useState({
    totalAppointments: 0,
    completedAppointments: 0,
    cartItems: 0,
    wishlistItems: 0,
    memberSince: "",
  })
  const router = useRouter()
  const { toast } = useToast()

  const [profileData, setProfileData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
  })

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  useEffect(() => {
    const userData = localStorage.getItem("servitec_user")
    if (!userData) {
      router.push("/auth")
      return
    }

    const user = JSON.parse(userData)
    setUser(user)
    setProfileData({
      name: user.name || "",
      email: user.email || "",
      phone: user.phone || "",
      address: user.address || "",
    })

    // Calculate user stats
    calculateStats(user)
  }, [router])

  const calculateStats = (user) => {
    // Get appointments
    const appointments = JSON.parse(localStorage.getItem("servitec_appointments") || "[]")
    const userAppointments = appointments.filter((apt) => apt.userId === user.id)

    // Get cart items
    const carritoCollection = JSON.parse(localStorage.getItem("carrito") || "[]")
    const userCart = carritoCollection.find((c) => c.userId === user.id)
    const cartItems = userCart ? userCart.items.reduce((total, item) => total + item.quantity, 0) : 0

    // Get wishlist items
    const wishlistCollection = JSON.parse(localStorage.getItem("lista_de_deseos") || "[]")
    const userWishlist = wishlistCollection.find((w) => w.userId === user.id)
    const wishlistItems = userWishlist ? userWishlist.items.length : 0

    setStats({
      totalAppointments: userAppointments.length,
      completedAppointments: userAppointments.filter((apt) => apt.status === "completed").length,
      cartItems,
      wishlistItems,
      memberSince: new Date(user.createdAt || Date.now()).toLocaleDateString("es-AR", {
        year: "numeric",
        month: "long",
      }),
    })
  }

  const handleProfileUpdate = async (e) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      // Update user in usuario collection
      const usuarioCollection = JSON.parse(localStorage.getItem("usuario") || "[]")
      const userIndex = usuarioCollection.findIndex((u) => u.id === user.id)

      if (userIndex !== -1) {
        usuarioCollection[userIndex] = {
          ...usuarioCollection[userIndex],
          ...profileData,
          updatedAt: new Date().toISOString(),
        }

        localStorage.setItem("usuario", JSON.stringify(usuarioCollection))
        localStorage.setItem("servitec_user", JSON.stringify(usuarioCollection[userIndex]))

        setUser(usuarioCollection[userIndex])

        // Trigger navbar update
        window.dispatchEvent(new CustomEvent("userUpdated"))

        toast({
          title: "Perfil actualizado",
          description: "Tus datos han sido actualizados correctamente.",
        })
      }

      setLoading(false)
    }, 1000)
  }

  const handlePasswordChange = async (e) => {
    e.preventDefault()

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Error",
        description: "Las contraseñas no coinciden.",
        variant: "destructive",
      })
      return
    }

    if (passwordData.newPassword.length < 6) {
      toast({
        title: "Error",
        description: "La contraseña debe tener al menos 6 caracteres.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      // Verify current password
      if (passwordData.currentPassword !== user.password) {
        toast({
          title: "Error",
          description: "La contraseña actual es incorrecta.",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      // Update password in usuario collection
      const usuarioCollection = JSON.parse(localStorage.getItem("usuario") || "[]")
      const userIndex = usuarioCollection.findIndex((u) => u.id === user.id)

      if (userIndex !== -1) {
        usuarioCollection[userIndex].password = passwordData.newPassword
        usuarioCollection[userIndex].updatedAt = new Date().toISOString()

        localStorage.setItem("usuario", JSON.stringify(usuarioCollection))
        localStorage.setItem("servitec_user", JSON.stringify(usuarioCollection[userIndex]))

        setUser(usuarioCollection[userIndex])

        toast({
          title: "Contraseña actualizada",
          description: "Tu contraseña ha sido cambiada correctamente.",
        })

        setPasswordData({
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        })
      }

      setLoading(false)
    }, 1000)
  }

  if (!user) {
    return <div>Cargando...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Button variant="ghost" onClick={() => router.back()} className="mr-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Mi Perfil</h1>
            <p className="text-gray-600">Gestiona tu información personal y configuración</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Summary */}
          <div className="lg:col-span-1">
            <Card className="bg-gradient-to-br from-purple-600 via-blue-600 to-cyan-500 text-white">
              <CardContent className="p-6">
                <div className="text-center">
                  <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="w-12 h-12" />
                  </div>
                  <h2 className="text-xl font-bold mb-2">{user.name}</h2>
                  <p className="text-white/80 mb-4">{user.email}</p>
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    {user.role === "administrador" ? "Administrador" : "Usuario"}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Stats */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg">Estadísticas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Calendar className="w-5 h-5 text-blue-500 mr-2" />
                    <span className="text-sm text-gray-600">Turnos totales</span>
                  </div>
                  <Badge variant="outline">{stats.totalAppointments}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Calendar className="w-5 h-5 text-green-500 mr-2" />
                    <span className="text-sm text-gray-600">Turnos completados</span>
                  </div>
                  <Badge variant="outline">{stats.completedAppointments}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <ShoppingCart className="w-5 h-5 text-orange-500 mr-2" />
                    <span className="text-sm text-gray-600">Items en carrito</span>
                  </div>
                  <Badge variant="outline">{stats.cartItems}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Heart className="w-5 h-5 text-red-500 mr-2" />
                    <span className="text-sm text-gray-600">Lista de deseos</span>
                  </div>
                  <Badge variant="outline">{stats.wishlistItems}</Badge>
                </div>
                <div className="pt-4 border-t">
                  <p className="text-sm text-gray-600">
                    Miembro desde <span className="font-medium">{stats.memberSince}</span>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Profile Forms */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="profile" className="space-y-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="profile">Información Personal</TabsTrigger>
                <TabsTrigger value="security">Seguridad</TabsTrigger>
              </TabsList>

              <TabsContent value="profile">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <User className="w-5 h-5 mr-2" />
                      Información Personal
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleProfileUpdate} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="name">Nombre completo</Label>
                          <div className="relative">
                            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                            <Input
                              id="name"
                              value={profileData.name}
                              onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                              className="pl-10"
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="email">Email</Label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                            <Input
                              id="email"
                              type="email"
                              value={profileData.email}
                              onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                              className="pl-10"
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="phone">Teléfono</Label>
                          <div className="relative">
                            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                            <Input
                              id="phone"
                              type="tel"
                              value={profileData.phone}
                              onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                              className="pl-10"
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="address">Dirección</Label>
                          <div className="relative">
                            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                            <Input
                              id="address"
                              value={profileData.address}
                              onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                              className="pl-10"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <Button
                          type="submit"
                          disabled={loading}
                          className="bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-700 hover:to-cyan-600"
                        >
                          <Save className="w-4 h-4 mr-2" />
                          {loading ? "Guardando..." : "Guardar Cambios"}
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="security">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Lock className="w-5 h-5 mr-2" />
                      Cambiar Contraseña
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handlePasswordChange} className="space-y-6">
                      <div>
                        <Label htmlFor="currentPassword">Contraseña actual</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            id="currentPassword"
                            type="password"
                            value={passwordData.currentPassword}
                            onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="newPassword">Nueva contraseña</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            id="newPassword"
                            type="password"
                            value={passwordData.newPassword}
                            onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                            className="pl-10"
                            required
                            minLength={6}
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="confirmPassword">Confirmar nueva contraseña</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            id="confirmPassword"
                            type="password"
                            value={passwordData.confirmPassword}
                            onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                            className="pl-10"
                            required
                            minLength={6}
                          />
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <Button
                          type="submit"
                          disabled={loading}
                          className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                        >
                          <Lock className="w-4 h-4 mr-2" />
                          {loading ? "Cambiando..." : "Cambiar Contraseña"}
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
