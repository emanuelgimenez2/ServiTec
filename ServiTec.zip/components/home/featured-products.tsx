"use client"

import { useState } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Star, ShoppingCart, Heart, Eye } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const products = [
  {
    id: 1,
    name: "Notebook HP Pavilion 15",
    price: 450000,
    originalPrice: 520000,
    rating: 4.8,
    reviews: 24,
    image: "/placeholder.svg?height=300&width=300",
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Notebooks",
    stock: 3,
    isNew: true,
    specifications: {
      Procesador: "Intel Core i5-12450H",
      "Memoria RAM": "8GB DDR4",
      Almacenamiento: "512GB SSD",
      Pantalla: '15.6" Full HD',
      "Tarjeta Gráfica": "Intel Iris Xe",
      "Sistema Operativo": "Windows 11 Home",
      Peso: "1.75 kg",
      Batería: "Hasta 8 horas",
    },
    description:
      "Notebook ideal para trabajo y entretenimiento con procesador Intel de última generación y diseño elegante.",
  },
  {
    id: 2,
    name: "Samsung Galaxy A54",
    price: 280000,
    originalPrice: 320000,
    rating: 4.6,
    reviews: 18,
    image: "/placeholder.svg?height=300&width=300",
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Celulares",
    stock: 5,
    isNew: false,
    specifications: {
      Pantalla: '6.4" Super AMOLED',
      Procesador: "Exynos 1380",
      "Memoria RAM": "8GB",
      Almacenamiento: "256GB",
      "Cámara Principal": "50MP + 12MP + 5MP",
      "Cámara Frontal": "32MP",
      Batería: "5000mAh",
      "Sistema Operativo": "Android 13",
    },
    description: "Smartphone con excelente cámara y pantalla AMOLED para una experiencia visual superior.",
  },
  {
    id: 3,
    name: "Parlante JBL Flip 6",
    price: 85000,
    originalPrice: 95000,
    rating: 4.9,
    reviews: 32,
    image: "/placeholder.svg?height=300&width=300",
    images: ["/placeholder.svg?height=600&width=600", "/placeholder.svg?height=600&width=600"],
    category: "Audio",
    stock: 8,
    isNew: false,
    specifications: {
      Potencia: "30W RMS",
      Conectividad: "Bluetooth 5.1",
      Resistencia: "IP67 (agua y polvo)",
      Batería: "Hasta 12 horas",
      Dimensiones: "178 x 68 x 72 mm",
      Peso: "550g",
      Colores: "Negro, Azul, Rojo, Verde",
      Extras: "PartyBoost compatible",
    },
    description: "Parlante portátil con sonido potente y resistencia al agua, perfecto para cualquier aventura.",
  },
  {
    id: 4,
    name: "Chromecast con Google TV",
    price: 45000,
    originalPrice: 55000,
    rating: 4.7,
    reviews: 15,
    image: "/placeholder.svg?height=300&width=300",
    images: ["/placeholder.svg?height=600&width=600", "/placeholder.svg?height=600&width=600"],
    category: "Streaming",
    stock: 12,
    isNew: true,
    specifications: {
      Resolución: "Hasta 4K HDR",
      Procesador: "Quad-core ARM Cortex-A55",
      Memoria: "8GB",
      Conectividad: "Wi-Fi 802.11ac, Bluetooth",
      Puertos: "HDMI, USB-C",
      "Control Remoto": "Incluido con Google Assistant",
      Servicios: "Netflix, YouTube, Disney+, Prime Video",
      Sistema: "Google TV",
    },
    description: "Convierte cualquier TV en Smart TV con acceso a miles de aplicaciones y contenido en 4K.",
  },
  {
    id: 5,
    name: "Amazon Echo Dot 5ta Gen",
    price: 35000,
    originalPrice: 42000,
    rating: 4.5,
    reviews: 28,
    image: "/placeholder.svg?height=300&width=300",
    images: ["/placeholder.svg?height=600&width=600", "/placeholder.svg?height=600&width=600"],
    category: "Smart Home",
    stock: 6,
    isNew: false,
    specifications: {
      Asistente: "Alexa integrado",
      Altavoz: '1.6" con audio mejorado',
      Conectividad: "Wi-Fi, Bluetooth",
      Dimensiones: "100 x 100 x 89 mm",
      Peso: "304g",
      Colores: "Blanco, Negro, Azul",
      Funciones: "Control de hogar inteligente",
      Micrófono: "Array de 4 micrófonos",
    },
    description: "Altavoz inteligente compacto con Alexa para controlar tu hogar inteligente y reproducir música.",
  },
  {
    id: 6,
    name: "MacBook Air M2",
    price: 1200000,
    originalPrice: 1350000,
    rating: 4.9,
    reviews: 12,
    image: "/placeholder.svg?height=300&width=300",
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    category: "Notebooks",
    stock: 2,
    isNew: true,
    specifications: {
      Procesador: "Apple M2 chip",
      "Memoria RAM": "8GB unificada",
      Almacenamiento: "256GB SSD",
      Pantalla: '13.6" Liquid Retina',
      Resolución: "2560 x 1664",
      Peso: "1.24 kg",
      Batería: "Hasta 18 horas",
      Sistema: "macOS Ventura",
    },
    description: "La laptop más delgada y liviana de Apple con el potente chip M2 para máximo rendimiento.",
  },
]

export default function FeaturedProducts() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [imageModalOpen, setImageModalOpen] = useState(false)
  const [selectedImageIndex, setSelectedImageIndex] = useState(0)
  const [wishlist, setWishlist] = useState(new Set())
  const itemsPerView = 4

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + itemsPerView >= products.length ? 0 : prev + itemsPerView))
  }

  const prevSlide = () => {
    setCurrentIndex((prev) =>
      prev - itemsPerView < 0 ? Math.max(0, products.length - itemsPerView) : prev - itemsPerView,
    )
  }

  const formatPrice = (price) => {
    return new Intl.NumberFormat("es-AR", {
      style: "currency",
      currency: "ARS",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const toggleWishlist = (productId) => {
    const newWishlist = new Set(wishlist)
    if (newWishlist.has(productId)) {
      newWishlist.delete(productId)
    } else {
      newWishlist.add(productId)
    }
    setWishlist(newWishlist)
  }

  const visibleProducts = products.slice(currentIndex, currentIndex + itemsPerView)

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Productos Destacados</h2>
            <p className="text-xl text-gray-600">Los productos más vendidos con los mejores precios</p>
          </div>

          {/* Navigation Buttons */}
          <div className="hidden md:flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={prevSlide}
              className="rounded-full w-10 h-10 p-0 border-purple-200 hover:border-purple-400"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={nextSlide}
              className="rounded-full w-10 h-10 p-0 border-purple-200 hover:border-purple-400"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Products Grid - Mobile: 2x2, Desktop: 4x1 */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {products.slice(0, window.innerWidth < 1024 ? 4 : products.length).map((product) => (
            <div key={product.id} className="w-full">
              <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border-0 shadow-md relative overflow-hidden">
                <CardContent className="p-0">
                  {/* Product Image */}
                  <div className="relative overflow-hidden rounded-t-lg">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={300}
                      height={300}
                      className="w-full h-48 lg:h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    {/* Badges */}
                    <div className="absolute top-3 left-3 flex flex-col space-y-2">
                      {product.isNew && (
                        <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs">
                          Nuevo
                        </Badge>
                      )}
                      {product.originalPrice > product.price && (
                        <Badge className="bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs">Oferta</Badge>
                      )}
                    </div>

                    {/* Stock Badge */}
                    <div className="absolute top-3 right-3">
                      <Badge variant="secondary" className="bg-white/90 text-gray-800 text-xs">
                        {product.stock <= 3 ? `Quedan ${product.stock}` : "En stock"}
                      </Badge>
                    </div>

                    {/* Wishlist Button */}
                    <button
                      onClick={() => toggleWishlist(product.id)}
                      className="absolute top-3 right-3 mt-8 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white"
                    >
                      <Heart
                        className={`w-4 h-4 ${wishlist.has(product.id) ? "text-red-500 fill-current" : "text-gray-600"}`}
                      />
                    </button>

                    {/* Hover Actions */}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <div className="flex flex-col space-y-2">
                        <Button size="sm" className="bg-white text-gray-900 hover:bg-gray-100">
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          Agregar al carrito
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-white/90 text-gray-900 hover:bg-white border-purple-200"
                          onClick={() => setSelectedProduct(product)}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Ver características
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-white/90 text-gray-900 hover:bg-white border-purple-200"
                          onClick={() => toggleWishlist(product.id)}
                        >
                          <Heart
                            className={`w-4 h-4 mr-2 ${wishlist.has(product.id) ? "text-red-500 fill-current" : ""}`}
                          />
                          Agregar a lista de deseos
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Product Info */}
                  <div className="p-3 lg:p-4">
                    <div className="mb-2">
                      <Badge variant="outline" className="text-xs border-purple-200 text-purple-700">
                        {product.category}
                      </Badge>
                    </div>

                    <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 text-sm lg:text-base">
                      {product.name}
                    </h3>

                    {/* Rating */}
                    <div className="flex items-center mb-3">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 lg:w-4 lg:h-4 ${
                              i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs lg:text-sm text-gray-600 ml-2">
                        {product.rating} ({product.reviews})
                      </span>
                    </div>

                    {/* Price */}
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-lg lg:text-2xl font-bold text-gray-900">
                            {formatPrice(product.price)}
                          </span>
                          {product.originalPrice > product.price && (
                            <span className="text-xs lg:text-sm text-gray-500 line-through">
                              {formatPrice(product.originalPrice)}
                            </span>
                          )}
                        </div>
                        {product.originalPrice > product.price && (
                          <div className="text-xs lg:text-sm text-green-600 font-medium">
                            Ahorrás {formatPrice(product.originalPrice - product.price)}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>

        {/* Mobile Navigation - Centered */}
        <div className="flex lg:hidden justify-center space-x-2 mt-8">
          <Button
            variant="outline"
            size="sm"
            onClick={prevSlide}
            className="rounded-full w-10 h-10 p-0 border-purple-200"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={nextSlide}
            className="rounded-full w-10 h-10 p-0 border-purple-200"
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>

        {/* Bottom CTA - Centered */}
        <div className="text-center mt-12">
          <Button
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700 text-white px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
          >
            Ver todos los productos
          </Button>
        </div>
      </div>

      {/* Product Details Modal */}
      <Dialog open={!!selectedProduct && !imageModalOpen} onOpenChange={() => setSelectedProduct(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedProduct && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold">{selectedProduct.name}</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="relative">
                    <Image
                      src={selectedProduct.images[selectedImageIndex] || selectedProduct.image || "/placeholder.svg"}
                      alt={selectedProduct.name}
                      width={400}
                      height={400}
                      className="w-full h-80 object-cover rounded-lg cursor-pointer"
                      onClick={() => setImageModalOpen(true)}
                    />
                    {selectedProduct.images.length > 1 && (
                      <>
                        <button
                          onClick={() =>
                            setSelectedImageIndex((prev) => (prev > 0 ? prev - 1 : selectedProduct.images.length - 1))
                          }
                          className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black/50 text-white rounded-full p-2 hover:bg-black/70"
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() =>
                            setSelectedImageIndex((prev) => (prev < selectedProduct.images.length - 1 ? prev + 1 : 0))
                          }
                          className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black/50 text-white rounded-full p-2 hover:bg-black/70"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
                <div>
                  <div className="mb-4">
                    <Badge className="bg-gradient-to-r from-purple-500 to-violet-500 text-white">
                      {selectedProduct.category}
                    </Badge>
                  </div>
                  <p className="text-gray-600 mb-4">{selectedProduct.description}</p>
                  <div className="flex items-center mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-5 h-5 ${
                            i < Math.floor(selectedProduct.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600 ml-2">
                      {selectedProduct.rating} ({selectedProduct.reviews} reseñas)
                    </span>
                  </div>
                  <div className="mb-6">
                    <div className="flex items-center space-x-3">
                      <span className="text-3xl font-bold text-gray-900">{formatPrice(selectedProduct.price)}</span>
                      {selectedProduct.originalPrice > selectedProduct.price && (
                        <span className="text-lg text-gray-500 line-through">
                          {formatPrice(selectedProduct.originalPrice)}
                        </span>
                      )}
                    </div>
                    {selectedProduct.originalPrice > selectedProduct.price && (
                      <div className="text-green-600 font-medium">
                        Ahorrás {formatPrice(selectedProduct.originalPrice - selectedProduct.price)}
                      </div>
                    )}
                  </div>
                  <div className="flex space-x-3 mb-6">
                    <Button className="flex-1 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700">
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Agregar al carrito
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => toggleWishlist(selectedProduct.id)}
                      className="border-purple-200 hover:border-purple-400"
                    >
                      <Heart
                        className={`w-4 h-4 ${wishlist.has(selectedProduct.id) ? "text-red-500 fill-current" : ""}`}
                      />
                    </Button>
                  </div>
                </div>
              </div>
              <Tabs defaultValue="specs" className="mt-6">
                <TabsList className="grid w-full grid-cols-1">
                  <TabsTrigger value="specs">Especificaciones</TabsTrigger>
                </TabsList>
                <TabsContent value="specs" className="mt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(selectedProduct.specifications).map(([key, value]) => (
                      <div key={key} className="flex justify-between py-2 border-b border-gray-100">
                        <span className="font-medium text-gray-700">{key}:</span>
                        <span className="text-gray-900">{value}</span>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Image Modal */}
      <Dialog open={imageModalOpen} onOpenChange={setImageModalOpen}>
        <DialogContent className="max-w-4xl">
          {selectedProduct && (
            <div className="relative">
              <Image
                src={selectedProduct.images[selectedImageIndex] || "/placeholder.svg"}
                alt={selectedProduct.name}
                width={800}
                height={600}
                className="w-full h-auto max-h-[70vh] object-contain"
              />
              <div className="flex justify-center space-x-2 mt-4">
                {selectedProduct.images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImageIndex(index)}
                    className={`w-3 h-3 rounded-full transition-all ${
                      index === selectedImageIndex ? "bg-purple-600" : "bg-gray-300 hover:bg-gray-400"
                    }`}
                  />
                ))}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  )
}
