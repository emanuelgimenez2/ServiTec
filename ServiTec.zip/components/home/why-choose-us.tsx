import { Award, Users, Clock, Shield } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const stats = [
  {
    icon: Award,
    number: "20+",
    label: "Antenas Starlink Instaladas",
    description: "Instalaciones exitosas con garantía completa",
  },
  {
    icon: Shield,
    number: "10+",
    label: "Sistemas de Cámaras",
    description: "Instalaciones de seguridad profesionales",
  },
  {
    icon: Users,
    number: "100+",
    label: "Notebooks Reparadas",
    description: "Clientes satisfechos con nuestro servicio",
  },
  {
    icon: Clock,
    number: "10+",
    label: "Páginas Web Creadas",
    description: "Sitios web 100% funcionales y optimizados",
  },
]

const reasons = [
  {
    title: "Experiencia Comprobada",
    description: "Años de experiencia en el sector tecnológico nos respaldan",
  },
  {
    title: "Garantía Total",
    description: "Todos nuestros servicios incluyen garantía completa",
  },
  {
    title: "Precios Competitivos",
    description: "Los mejores precios del mercado sin comprometer la calidad",
  },
  {
    title: "Atención Personalizada",
    description: "Cada cliente recibe un trato personalizado y profesional",
  },
  {
    title: "Soporte Continuo",
    description: "Estamos disponibles para resolver cualquier consulta",
  },
  {
    title: "Tecnología Actualizada",
    description: "Trabajamos con las últimas tecnologías del mercado",
  },
]

export default function WhyChooseUs() {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">¿Por qué elegir ServiTec?</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Nuestra trayectoria y compromiso nos convierten en la mejor opción para tus necesidades tecnológicas
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon
            return (
              <Card
                key={index}
                className="text-center border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
              >
                <CardContent className="p-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-purple-600 to-violet-600 rounded-full mb-4">
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-4xl font-bold text-gray-900 mb-2">{stat.number}</div>
                  <div className="text-lg font-semibold text-gray-800 mb-2">{stat.label}</div>
                  <p className="text-gray-600 text-sm">{stat.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Reasons Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className="flex items-start space-x-4 p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-300 border border-purple-100 hover:border-purple-200"
            >
              <div className="flex-shrink-0">
                <div className="w-3 h-3 bg-gradient-to-r from-purple-400 to-violet-400 rounded-full mt-2" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{reason.title}</h3>
                <p className="text-gray-600">{reason.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Story Section */}
        <div className="mt-20 bg-gradient-to-r from-purple-900 via-violet-900 to-purple-800 rounded-2xl p-8 md:p-12 text-white">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-3xl md:text-4xl font-bold mb-6">Nuestra Historia</h3>
            <p className="text-lg md:text-xl leading-relaxed text-white/90">
              Iniciamos como pareja arreglando notebooks hasta que nos dimos cuenta de lo mucho que podíamos crecer. Hoy
              ya colocamos más de 20 antenas, más de 10 cámaras, arreglamos más de 100 notebooks y creamos más de 10
              páginas web 100% funcionales con clientes conformes (incluyendo esta página web).
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-8 text-center">
              <div>
                <div className="text-3xl font-bold text-violet-300">2019</div>
                <div className="text-white/80">Año de inicio</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-violet-300">100%</div>
                <div className="text-white/80">Clientes satisfechos</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-violet-300">24/7</div>
                <div className="text-white/80">Soporte disponible</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
