"use client"

import { useState, useEffect } from "react"
import { Star, Quote } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const testimonials = [
  {
    id: 1,
    name: "María González",
    role: "Propietaria de Café Central",
    rating: 5,
    comment:
      "Excelente servicio! Me instalaron las cámaras de seguridad en mi local y quedé muy conforme. Muy profesionales y el precio fue justo.",
    avatar: "/placeholder.svg?height=60&width=60",
    service: "Instalación de Cámaras",
  },
  {
    id: 2,
    name: "Carlos Rodríguez",
    role: "Ingeniero",
    rating: 5,
    comment:
      "Mi notebook tenía problemas graves y pensé que no tenía arreglo. Los chicos de ServiTec la dejaron como nueva. Súper recomendable!",
    avatar: "/placeholder.svg?height=60&width=60",
    service: "Reparación de Computadoras",
  },
  {
    id: 3,
    name: "Ana Martínez",
    role: "Contadora",
    rating: 5,
    comment:
      "Necesitaba internet en mi campo y me instalaron Starlink. El servicio fue impecable, desde la instalación hasta la configuración.",
    avatar: "/placeholder.svg?height=60&width=60",
    service: "Instalación Starlink",
  },
  {
    id: 4,
    name: "Roberto Silva",
    role: "Comerciante",
    rating: 5,
    comment:
      "Me desarrollaron la página web de mi negocio y quedó espectacular. Muy profesionales y atentos a todos los detalles.",
    avatar: "/placeholder.svg?height=60&width=60",
    service: "Desarrollo Web",
  },
  {
    id: 5,
    name: "Laura Fernández",
    role: "Arquitecta",
    rating: 5,
    comment:
      "Compré una notebook en ServiTec y el servicio post-venta es excelente. Siempre están disponibles para cualquier consulta.",
    avatar: "/placeholder.svg?height=60&width=60",
    service: "Venta de Productos",
  },
]

export default function Testimonials() {
  const [currentTestimonial, setCurrentTestimonial] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 4000)

    return () => clearInterval(timer)
  }, [])

  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Lo que dicen nuestros clientes</h2>
          <p className="text-xl text-white/80 max-w-3xl mx-auto">
            La satisfacción de nuestros clientes es nuestra mejor carta de presentación
          </p>
        </div>

        {/* Main Testimonial */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
            <CardContent className="p-8 md:p-12">
              <div className="flex items-center justify-center mb-8">
                <Quote className="w-12 h-12 text-orange-400" />
              </div>

              <blockquote className="text-xl md:text-2xl text-center mb-8 leading-relaxed">
                "{testimonials[currentTestimonial].comment}"
              </blockquote>

              <div className="flex items-center justify-center mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-6 h-6 ${
                      i < testimonials[currentTestimonial].rating ? "text-yellow-400 fill-current" : "text-gray-400"
                    }`}
                  />
                ))}
              </div>

              <div className="flex items-center justify-center space-x-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={testimonials[currentTestimonial].avatar || "/placeholder.svg"} />
                  <AvatarFallback className="bg-gradient-to-r from-orange-400 to-red-400 text-white">
                    {testimonials[currentTestimonial].name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <div className="font-semibold text-lg">{testimonials[currentTestimonial].name}</div>
                  <div className="text-white/70">{testimonials[currentTestimonial].role}</div>
                  <div className="text-orange-400 text-sm">{testimonials[currentTestimonial].service}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Testimonial Indicators */}
        <div className="flex justify-center space-x-3 mb-12">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentTestimonial(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentTestimonial ? "bg-orange-400 scale-125" : "bg-white/30 hover:bg-white/50"
              }`}
            />
          ))}
        </div>

        {/* All Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.slice(0, 3).map((testimonial, index) => (
            <Card
              key={testimonial.id}
              className="bg-white/5 backdrop-blur-sm border-white/10 text-white hover:bg-white/10 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${i < testimonial.rating ? "text-yellow-400 fill-current" : "text-gray-400"}`}
                    />
                  ))}
                </div>

                <p className="text-white/90 mb-4 text-sm leading-relaxed">"{testimonial.comment}"</p>

                <div className="flex items-center space-x-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={testimonial.avatar || "/placeholder.svg"} />
                    <AvatarFallback className="bg-gradient-to-r from-orange-400 to-red-400 text-white text-sm">
                      {testimonial.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-sm">{testimonial.name}</div>
                    <div className="text-white/60 text-xs">{testimonial.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
